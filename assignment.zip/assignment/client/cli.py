from getpass import getpass
import requests
import json

print("Use this script on CLI!")

while True:

    print("Welcome to weather API, login to continue:")
    
    print("Enter username:")
    username = input()

    print("Enter password:")
    password = getpass()

    # call /token endpoint to get a token aka login
    login_url = 'http://web:8000/token/'
    creds = {
        "username": username,
        "password": password
    }

    login_res = requests.post(login_url, json = creds)
    login_response = json.loads(login_res.text)
    user_token = login_response["token"]    
    print(user_token)

    login_flag = True
    authorization_val = 'Token ' + user_token


    while login_flag:

        print("\n \n Choose among following query (input the query no. you want to run):")
        print("1. Get Weather")
        print("2. Get Bill")
        print("3. All queries of user")
        print("4. Last login of user")
        print("5. All login of user")
        print("6. All users in the system")
        print("7. Logout")
        input_choice = input("\nEnter your choice : ")

        if input_choice == '1':
            latitude = input("\nEnter latitude : ")
            longitude = input("Enter longitude : ")
            print("\nLoading the temparture value (Please wait) .... ")

            
            weather_url = 'http://web:8000/forecast/?latitude=' + latitude + '&longitude=' +  longitude + '&timezone=Asia/Calcutta'
            weather_res = requests.get(weather_url, headers={"Authorization": authorization_val})
            weather_response = json.loads(weather_res.text)

            temperature = weather_response["data"]["temperature"]
            print("Temperature of the day (in °F): " + str(temperature))

        elif input_choice == '2':

            bill_url = 'http://web:8000/bill'
            bill_res = requests.get(bill_url, headers={"Authorization": authorization_val})
            bill_response = json.loads(bill_res.text)

            bill_cost = bill_response["data"]["cost"]
            print("Bill value : " + str(bill_cost))

        elif input_choice == '3':

            user_queries_url = 'http://web:8000/queries'
            user_queries_res = requests.get(user_queries_url, headers={"Authorization": authorization_val})
            user_queries_response = json.loads(user_queries_res.text)
        
            for user_query in user_queries_response:
                created = user_query['created']
                query = user_query['query']
                print("Query Time (GMT) : " + created + " Query : " + query)

        elif input_choice == '4':
            last_login_url = 'http://web:8000/last-login'
            last_login_res = requests.get(last_login_url, headers={"Authorization": authorization_val})
            last_login_response = json.loads(last_login_res.text)

            last_login_time = last_login_response[0]['lastlogin']

            print("Last login time of user (in GMT): " + last_login_time)
            
        elif input_choice == '5':
            all_login_url = 'http://web:8000/logins'
            all_login_res = requests.get(all_login_url, headers={"Authorization": authorization_val})
            all_login_response = json.loads(all_login_res.text)

            print("All Login time (in GMT):")

            for login in all_login_response:
                login_time = login['lastlogin']
                print(" " + login_time)

        elif input_choice == '6':
            all_users_url = 'http://web:8000/users'
            all_users_res = requests.get(all_users_url, headers={"Authorization": authorization_val})
            all_users_response = json.loads(all_users_res.text)

            user_list = all_users_response['data']['users']

            print("All users in the system :")

            i = 1
            for user in user_list:
                username = user["username"]
                name = user["name"]
                last_login = user["last_login"] if user["last_login"] else ""

                print(str(i) + ":")
                print("\tUserName: " + username )
                print("\tName: " + name)
                print("\tLast Login Time (in GMT): " + last_login)
                i=i+1

        elif input_choice == '7':
            login_flag = False

        else :
            print("\nPlease select the correct choice!!!")

            


    