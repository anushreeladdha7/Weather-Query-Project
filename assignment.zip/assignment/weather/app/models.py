from django.db import models
from django.contrib.auth.models import User

class UserLogin(models.Model):
    lastlogin = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self) -> str:
        return '{0}__{1}'.format(self.user.username, self.lastlogin)

class WeatherQuery(models.Model):
    created = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    query = models.TextField()

    def __str__(self) -> str:
        return self.user.username + '__' + str(self.pk)