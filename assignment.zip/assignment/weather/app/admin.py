from django.contrib import admin
from app.models import UserLogin, WeatherQuery

# Register your models here.
admin.site.register(WeatherQuery)
admin.site.register(UserLogin)