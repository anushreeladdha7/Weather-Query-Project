from app.models import UserLogin, WeatherQuery
from rest_framework import serializers

class QuerySerializer(serializers.ModelSerializer):

    class Meta:
        model = WeatherQuery
        fields = '__all__'

class UserLoginSerializer(serializers.ModelSerializer):

    class Meta:
        model = UserLogin
        fields = ('user', 'lastlogin')