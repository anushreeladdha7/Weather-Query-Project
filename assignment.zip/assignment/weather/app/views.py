import json
import requests
from django.conf import settings
from django.contrib.auth.models import User

from rest_framework.views import APIView
from rest_framework.generics import ListAPIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.authtoken.views import ObtainAuthToken

from rest_framework.permissions import IsAuthenticated

from app.models import UserLogin, WeatherQuery
from app.serializers import QuerySerializer, UserLoginSerializer

class BillView(APIView):

    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        queries = WeatherQuery.objects.filter(user=user).count()

        return Response({
            'success': True,
            'data': {
                'cost': queries * 0.18
            }
        })

# Create your views here.
class WeatherQueryAPIView(APIView):

    permission_classes = [IsAuthenticated]

    def get(self, request):

        data = request.GET
        user = request.user
        latitude = data.get('latitude')
        longitude = data.get('longitude')
        tz = data.get('timezone')

        try:

            if not latitude or not longitude or not tz:
                raise Exception('Invalid data')

            url = '{0}&latitude={1}&longitude={2}&timezone={3}'.format(settings.WEATHER_URL, latitude, longitude, tz)

            resp = requests.get(url)
            resp = resp.json()

            temperature_2m_max = resp['daily']['temperature_2m_max'][0]

            query = WeatherQuery(user=user, query=json.dumps(request.GET))
            query.save()

            return Response({
                'success': True,
                'data': {
                    'latitude': latitude,
                    'longitude': longitude,
                    'temperature': temperature_2m_max
                }
            })
        
        except Exception as ex:
            return Response({
                'success': False,
                'error': str(ex)
            }, status=status.HTTP_400_BAD_REQUEST)


class UserQueryAPI(ListAPIView):

    permission_classes = [IsAuthenticated]
    serializer_class = QuerySerializer

    def get_queryset(self):
        user = self.request.user
        user_queries = WeatherQuery.objects.filter(user=user)
        return user_queries

class CustomTokenView(ObtainAuthToken):

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, created = Token.objects.get_or_create(user=user)

        # create last login for user
        log = UserLogin(user=user)
        log.save()

        return Response({'token': token.key})

class LastLoginView(ListAPIView):

    permission_classes = [IsAuthenticated]
    serializer_class = UserLoginSerializer

    def get_queryset(self):
        user = self.request.user
        return UserLogin.objects.filter(user=user).order_by('-lastlogin')[:1]

class UserLoginView(ListAPIView):

    permission_classes = [IsAuthenticated]
    serializer_class = UserLoginSerializer

    def get_queryset(self):
        user = self.request.user
        return UserLogin.objects.filter(user=user).order_by('-lastlogin')


class UserView(APIView):

    permission_classes = [IsAuthenticated]

    def get(self, request):
        users = []

        for user in User.objects.all():
            last_login = UserLogin.objects.filter(user=user).order_by('-lastlogin')[:1]

            last_login = last_login.first()

            users.append({
                'id': user.id,
                'username': user.username,
                'name': user.get_full_name(),
                'last_login': last_login.lastlogin if last_login else None,

            })

        return Response({
            'success': True,
            'data': {
                'users': users
            }
        })