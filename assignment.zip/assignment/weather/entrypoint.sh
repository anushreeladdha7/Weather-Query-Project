#!/bin/bash

set -e

echo "${0}: running migrations."
python /code/weather/manage.py makemigrations --merge
python /code/weather/manage.py migrate --noinput
python /code/weather/manage.py loaddata /code/weather/init.json
python /code/weather/manage.py runserver 0.0.0.0:8000
# echo "${0}: collecting statics."

# python ./weather/manage.py collectstatic --noinput

# cp -rv static/* static_shared/

# gunicorn weather.wsgi:application \
#     --env DJANGO_SETTINGS_MODULE=weather.settings \
#     --name weather \
#     --bind 0.0.0.0:8000 \
#     --timeout 600 \
#     --workers 4 \
#     --log-level=info \
#     --reload