#Pre-requisite is docker/docker desktop
#Docker files are created for web, client & mongo
#To run them all use the below command to compose

1. docker compose -f stack.yml up

#Once the containers are running for all 3 images (Mongo, Web, Client) exec the Cli container

2. docker exec -it <container-id-of-cli> sh

#Or you can open the CLI terminal in Docker Deskstop for cli container

#Once the above step is complete run the cli.py file

3. python3 /code/cli.py

#This will run the client & you can start by logging in by entering username & password.
#The app already has 4 user in system whose credentials are:
     UserName            Password
1.   admin               admin
2.   anushri             strongpassword
3.   rutushri            strongpassword
4.   tempuser            strongpassword

#Once you are logged in, you can query for multiple things.

For reference a video link is attached here:  https://youtu.be/25CLyrIVb4s




